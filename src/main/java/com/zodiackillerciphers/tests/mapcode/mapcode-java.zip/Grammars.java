package com.zodiackillerciphers.tests.mapcode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Grammars {

	/**
	 * it is assumed that an optional delimiter exists between each grammar
	 * element
	 */
	public static GrammarElement[][] grammars = new GrammarElement[][] {
			{ GrammarElement.MILS_AMOUNT, GrammarElement.MILS_UNIT,
					GrammarElement.CONJUNCTION, GrammarElement.INCHES_AMOUNT,
					GrammarElement.INCHES_UNIT },
			{ GrammarElement.INCHES_AMOUNT, GrammarElement.INCHES_UNIT,
					GrammarElement.CONJUNCTION, GrammarElement.MILS_AMOUNT,
					GrammarElement.MILS_UNIT } };

	public static String[] mils = new String[] { "MILS", "MIL", "MILLIRADIAN",
			"MILLIRADIANS" };

	public static String[] radians = new String[] { "RADIANS", "RADS", "RAD" };

	public static String[] inches = new String[] { "INCHES", "INCH", "IN" };

	public static int[] denominators = new int[] { 2, 3, 4, 5, 8, 10, 16, 32 };

	public static List<String> grammarElementToStrings(GrammarElement element,
			boolean fraction, String delimiter) {
		List<String> list = new ArrayList<String>();
		if (element == null)
			return list;
		if (element == GrammarElement.MILS_AMOUNT) {
			for (int mils = 0; mils <= 64; mils++) {
				list.add("" + mils);
				list.add(EnglishNumberToWords.convertUpper(mils));
				// if (mils >= 10)
				// list.add(EnglishNumberToWords.convertUpperDigits(mils));
				if (fraction) {
					for (int d : denominators) {
						for (int n = 0; n < d; n++) {
							if (n == 0 && mils == 0)
								continue;
							list.addAll(FractionGenerator.generate(mils, n, d,
									" ".equals(delimiter)));

						}

					}
				}
			}
		} else if (element == GrammarElement.CONJUNCTION) {
			list.add("AND");
			list.add("&");
			list.add("+");
			list.add("");
		} else if (element == GrammarElement.INCHES_AMOUNT) {
			for (int inches = 0; inches <= 8; inches++) {
				list.add("" + inches);
				list.add(EnglishNumberToWords.convertUpper(inches));
				if (fraction) {
					for (int d : denominators) {
						for (int n = 0; n < d; n++) {
							if (n == 0 && inches == 0)
								continue;
							list.addAll(FractionGenerator.generate(inches, n,
									d, " ".equals(delimiter)));

						}

					}
				}
			}
		} else if (element == GrammarElement.INCHES_UNIT) {
			list.addAll(Arrays.asList(inches));
		} else if (element == GrammarElement.MILS_UNIT) {
			list.addAll(Arrays.asList(mils));
			list.addAll(Arrays.asList(radians));
		}
		return list;
	}
}
