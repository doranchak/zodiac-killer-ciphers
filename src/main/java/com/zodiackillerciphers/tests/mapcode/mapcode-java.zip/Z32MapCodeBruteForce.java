package com.zodiackillerciphers.tests.mapcode;

public class Z32MapCodeBruteForce {


	static void search(int which) {
//		long total = 1;
//		for (GrammarElement ge : Grammars.grammars[which]) {
//			total *= Grammars.grammarElementToStrings(ge).size();
//		}
//		
//		total *= 2; // because of two possible delimiters between grammar elements
//		System.out.println("SEARCH SPACE: " + total);
		
		search(new StringBuffer(), new StringBuffer(), Grammars.grammars[which], 0, "", true);
		search(new StringBuffer(), new StringBuffer(), Grammars.grammars[which], 0, " ", true);
	}
	
	static void search(StringBuffer sb, StringBuffer description, GrammarElement[] grammar, int index, String delimiter, boolean fractions) {
//		System.out.println(sb + " (" + index + ")");
		if (!valid(sb)) {
//			System.out.println("INVALID: " + sb);
			return; // violates cipher constraints
		}
		if (index >= grammar.length) {
			// we reached the end without violating a constraint
			if (sb.length() == 32) {
				// success!
//				System.out.println("SUCCESS: " + sb + (" ".equals(delimiter) ? "" : "  (" + description + ")"));
				System.out.println(sb);
			} 
//			else System.out.println("INCOMPLETE: " + sb);
			return; 
		}
		
		GrammarElement element = grammar[index];
		int originalLength = sb.length();
		int originalLength2 = description.length();
		for (String elemStr : Grammars.grammarElementToStrings(element, fractions, delimiter)) {
//				System.out.println(delimiter + "," + elemStr);
			if (" ".equals(delimiter) && sb.length() > 0 && sb.charAt(sb.length()-1) != ' ')
				sb.append(delimiter);
			sb.append(elemStr);
			description.append(elemStr + " ");
			search(sb, description, grammar, index+1, delimiter, fractions);
			// revert string after recursion
			sb.replace(originalLength, sb.length(), "");
			description.replace(originalLength2, description.length(), "");
		}
	}
	
	/** 
	 * C9J|#OktAMf8oORTGX6FDVj%HCELzPW9
	 * 
	 * repeated symbols are O, C, and 9
	 * O repeats at 5 and 13
	 * C repeats at 0 and 25
	 * 9 repeats at 1 and 31
	 * 
	 */
	static boolean valid(StringBuffer sb) {
		if (sb.length() > 32) return false; // too long
		if (sb.length() > 13) 
			if (sb.charAt(5) != sb.charAt(13)) return false;
		if (sb.length() > 25) 
			if (sb.charAt(0) != sb.charAt(25)) return false;
		if (sb.length() > 31) 
			if (sb.charAt(1) != sb.charAt(31)) return false;
		return true;
	}
	
	public static void main(String[] args) {
//		StringBuffer sb = new StringBuffer("SHITBALLS");
//		sb.replace(4,sb.length(),"");
//		System.out.println(sb);
		search(0);
	}
}
