package com.zodiackillerciphers.tests.mapcode;

public enum GrammarElement {
	MILS_AMOUNT, // 0-64
	MILS_UNIT,
	CONJUNCTION,
	INCHES_AMOUNT, // 0-8
	INCHES_UNIT,
}
