/*
	1: pick a point (i,j)
	2: choose a direction [d1] from {up, right, down, left}
	3: advance in direction [d1] until a boundary is reached
	4: choose [d2], one of the two directions perpendicular to [d1].
	5: advance one position in this direction
	6: zigzag until boundary is reached
	
*/	
	