function renderSymbols() {
	var inp=$("input").value;
	if (!inp || inp=="") {
		clear();
		return;
	}
	
	var split=inp.split("\n");
	
	var html = "";
	var forum = "";
	for (var i=0; i<split.length; i++) {
		for (var j=0; j<split[i].length; j++) {
			html += '<img src="http://oranchak.com/zodiac/webtoy/alphabet/' + getName(split[i].charAt(j), true) + '.jpg">';
			forum += '[img]http://oranchak.com/zodiac/webtoy/alphabet/' + getName(split[i].charAt(j), true) + '.jpg[/img]';
		}
		if (i<split.length-1) {
			html += "<br>";
			forum += "\n";
		}
	}
	$("symbols").innerHTML = html;
	
	$("source-html").value = html;
	$("source-forum").value = forum;
}
	
function clear() {
	$("source-html").value = "";
	$("source-forum").value = "";
}	